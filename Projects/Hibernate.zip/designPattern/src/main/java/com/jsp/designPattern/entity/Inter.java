package com.jsp.designPattern.entity;

@FunctionalInterface
public interface Inter {

	void fuck();
//	void noJob();
	
	public static final int a = 200;
}
