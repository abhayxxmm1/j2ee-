package com.jsp.designPattern.entity;

public interface Parent {

//	static {
//		
//	}
	
//	{
//		
//	}
	
	public static final int a = 20;
	
	void nonStatic();
	
	//	void static(); 
	default void defaultNonStatic() {
		System.out.println("Default NonStatic is allowed from jdk 8");
	}
	
	static void isStatic() {
		System.out.println("Concreate static block is allowed bcoz it cannot be inherited from parent class");
	}
	
	public static void main(String[] args) {
		
		System.err.println("We can pass main method here!!");
		System.out.println();
		Parent.isStatic();
		
		System.out.println("we cannnot pass non-static members");
		
		System.err.println("what are concreate non-static members");
	}
	
}
