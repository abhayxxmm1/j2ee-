package com.jsp.hql.driver;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.hibernate.sql.Delete;

import com.jsp.hql.entity.Mobile;

public class MobileDriver {

	public static void main(String[] args) {
		
		EntityManager em = Persistence.createEntityManagerFactory("pg").createEntityManager();
		
		EntityTransaction et = em.getTransaction();
		
//		Mobile m1 = new Mobile(101, "Vivo", 29999.0);
//		Mobile m2 = new Mobile(102, "oppo", 17999.0);
//		Mobile m3 = new Mobile(103, "redmi", 38999.0);
//		
//		et.begin();
//		em.persist(m1);
//		em.persist(m2);
//		em.persist(m3);
//		et.commit();
		
//		Query query = em.createQuery("from Mobile");
//		List<Mobile> list= query.getResultList();
//		list.forEach(System.out::println);
		
		Query query2 = em.createQuery("from Mobile  where id=102");
//1		Object singleResult = query2.getSingleResult();	/// return type is Object
//		System.out.println(singleResult);
		Mobile singleResult = (Mobile) query2.getSingleResult();	/// return type is Object : need to downcast
		System.out.println(singleResult);
		
		
		et.begin();
///		Delete sql query:- delete from mobile where id=101
///		Delete dql query:- delete from mobile e where e.id=101
		
//		Query query3 = em.createQuery("delete from Mobile  where id=101");
//		int executeUpdate = query3.executeUpdate();
//		if(executeUpdate!=0)
//			System.out.println("HQL Query executed");
//		else
//			System.out.println("HQL Query not executed");
		
///		update sql query:-UPDATE MOBILE SET NAME="REALMI" WHERE ID="103"		
///		Delete dql query:-update Mobile e set e.name ='rabdi' where e.id=103
		
		
		Query query4 = em.createQuery("update Mobile e set e.name ='rabdi' where e.id=103");
		int executeUpdate = query4.executeUpdate();
		if(executeUpdate!=0)
			System.out.println("HQL Query executed");
		else
			System.out.println("HQL Query not executed");
		
		
		
		et.commit();
		
		
	}
}
