package attention;

public class Logic {

	private static String URl = "jdbc:postgres://localhost:5432/un";
	private static String USN = "postgres";
	private static String PWD = "root";
}
