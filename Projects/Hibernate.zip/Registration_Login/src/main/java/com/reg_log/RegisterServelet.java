package com.reg_log;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/register")
public class RegisterServelet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		String cp = req.getParameter("cp");

		JDBCLogic jdbc = new JDBCLogic();
		jdbc.save(name, email,password, cp);
		
		if (password.equals(cp)) {
			
		PrintWriter pw = resp.getWriter();
		pw.print("<h1>Username ="+ name +"<h1>");
		pw.print("<h1>Email ="+ email +"<h1>");
		pw.print("<h1>Password ="+ password +"<h1>");
		pw.print("<h1>Email ="+ cp +"<h1>");
		
		}else {
			PrintWriter pw = resp.getWriter();
			pw.print("<h1>Wrong Credentials<h1>");
			RequestDispatcher rd = req.getRequestDispatcher("Registration.html");
			rd.include(req, resp);
		}
			
		
	}
}
